/**
 * Print Enforcer Service
 *
 * Ensures ALL printing on the machine goes through SecurePrint.
 *
 * Capabilities:
 *   1. Print Spooler Monitor — subscribes to native Windows printer change notifications,
 *      cancels unauthorized jobs, and shows a notification.
 *   2. Direct-IP Printer Blocking — can optionally block network ports used by
 *      printers (9100/TCP, 515/TCP, 631/TCP) via Windows Firewall.
 *   3. Printer Lockdown — hides/disables printers not approved by SecurePrint.
 *
 * The enforcer runs in the Electron main process with a persistent PowerShell event watcher.
 * It requires administrator privileges for firewall rules.
 */

const { exec, spawn } = require('child_process');
const path = require('path');
const os = require('os');
const { Notification } = require('electron');

// Set of document names currently being printed by SecurePrint
const whitelistedJobs = new Set();
let monitorProcess = null;
let isMonitoring = false;
let monitorRestartTimer = null;
let monitorRestartDelay = 1000;
const recentlySeenJobs = new Map();

// ─── Whitelist Management ───

function whitelistJob(documentName) {
  const key = documentName.toLowerCase().trim();
  whitelistedJobs.add(key);
  console.log('[PrintEnforcer] Whitelisted job:', key);
  // Auto-remove after 60 seconds to prevent stale entries
  setTimeout(() => {
    whitelistedJobs.delete(key);
  }, 60000);
}

function removeWhitelistedJob(documentName) {
  whitelistedJobs.delete(documentName.toLowerCase().trim());
}

function isJobWhitelisted(documentName) {
  if (!documentName) return false;
  const key = documentName.toLowerCase().trim();
  // Check exact match or partial match (printer drivers may alter the name)
  for (const wl of whitelistedJobs) {
    if (key.includes(wl) || wl.includes(key)) return true;
  }
  return false;
}

// ─── Print Spooler Monitor ───

function startMonitoring() {
  if (isMonitoring) return;
  if (process.platform !== 'win32') {
    console.log('[PrintEnforcer] Spooler monitoring only supported on Windows.');
    return;
  }

  isMonitoring = true;
  console.log('[PrintEnforcer] Starting print spooler monitor...');
  launchMonitorProcess();
}

function stopMonitoring() {
  isMonitoring = false;
  if (monitorRestartTimer) {
    clearTimeout(monitorRestartTimer);
    monitorRestartTimer = null;
  }
  if (monitorProcess) {
    monitorProcess.removeAllListeners('close');
    monitorProcess.kill();
    monitorProcess = null;
  }
  console.log('[PrintEnforcer] Spooler monitor stopped.');
}

function encodePowerShell(script) {
  return Buffer.from(script, 'utf16le').toString('base64');
}

function createMonitorScript() {
  return `
$ErrorActionPreference = 'Stop'
$script:printerNames = @()
$script:spoolerRunning = $false
$script:printerInventory = ''
$script:nextHealthCheck = [DateTime]::UtcNow

function Send-Message($type, $data) {
  $message = @{ type = $type }
  foreach ($key in $data.Keys) { $message[$key] = $data[$key] }
  [Console]::Out.WriteLine(($message | ConvertTo-Json -Compress -Depth 4))
  [Console]::Out.Flush()
}

$nativeSource = @'
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.InteropServices;

public static class SecurePrintChangeWatcher {
    private sealed class PrinterWatch {
        public string Name;
        public IntPtr Printer;
        public IntPtr Change;
    }

    private static readonly List<PrinterWatch> Watches = new List<PrinterWatch>();
    private const uint PrinterChangeAddJob = 0x00000100;
    private const uint WaitObject0 = 0x00000000;
    private const uint WaitTimeout = 0x00000102;
    private const uint WaitFailed = 0xFFFFFFFF;
    private static readonly IntPtr InvalidHandle = new IntPtr(-1);

    [DllImport("winspool.drv", SetLastError = true, CharSet = CharSet.Unicode)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool OpenPrinter(string name, out IntPtr printer, IntPtr defaults);

    [DllImport("winspool.drv", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ClosePrinter(IntPtr printer);

    [DllImport("winspool.drv", SetLastError = true)]
    private static extern IntPtr FindFirstPrinterChangeNotification(IntPtr printer, uint filter, uint options, IntPtr notifyOptions);

    [DllImport("winspool.drv", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FindNextPrinterChangeNotification(IntPtr change, out uint changes, IntPtr options, out IntPtr notifyInfo);

    [DllImport("winspool.drv", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FindClosePrinterChangeNotification(IntPtr change);

    [DllImport("winspool.drv")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool FreePrinterNotifyInfo(IntPtr notifyInfo);

    [DllImport("kernel32.dll", SetLastError = true)]
    private static extern uint WaitForMultipleObjects(uint count, IntPtr[] handles, bool waitAll, uint milliseconds);

    public static void Start(string[] names) {
        Stop();
        foreach (string name in names) {
            IntPtr printer;
            if (!OpenPrinter(name, out printer, IntPtr.Zero))
                throw new Win32Exception(Marshal.GetLastWin32Error(), "OpenPrinter failed for " + name);
            IntPtr change = FindFirstPrinterChangeNotification(printer, PrinterChangeAddJob, 0, IntPtr.Zero);
            if (change == InvalidHandle) {
                int error = Marshal.GetLastWin32Error();
                ClosePrinter(printer);
                throw new Win32Exception(error, "Could not subscribe to print-job changes for " + name);
            }
            Watches.Add(new PrinterWatch { Name = name, Printer = printer, Change = change });
        }
    }

    public static int Wait(int milliseconds) {
        if (Watches.Count == 0) return -2;
        int groupCount = (Watches.Count + 63) / 64;
        int groupTimeout = Math.Max(1, milliseconds / groupCount);
        for (int group = 0; group < groupCount; group++) {
            int start = group * 64;
            int count = Math.Min(64, Watches.Count - start);
            IntPtr[] handles = new IntPtr[count];
            for (int i = 0; i < count; i++) handles[i] = Watches[start + i].Change;
            uint result = WaitForMultipleObjects((uint)handles.Length, handles, false, (uint)groupTimeout);
            if (result == WaitTimeout) continue;
            if (result == WaitFailed || result < WaitObject0 || result >= WaitObject0 + handles.Length) return -2;
            return start + (int)(result - WaitObject0);
        }
        return -1;
    }

    public static string Consume(int index) {
        if (index < 0 || index >= Watches.Count) return null;
        uint changes;
        IntPtr info;
        if (!FindNextPrinterChangeNotification(Watches[index].Change, out changes, IntPtr.Zero, out info))
            throw new Win32Exception(Marshal.GetLastWin32Error(), "Print change notification failed for " + Watches[index].Name);
        if (info != IntPtr.Zero) FreePrinterNotifyInfo(info);
        return Watches[index].Name;
    }

    public static void Stop() {
        foreach (PrinterWatch watch in Watches) {
            if (watch.Change != IntPtr.Zero) FindClosePrinterChangeNotification(watch.Change);
            if (watch.Printer != IntPtr.Zero) ClosePrinter(watch.Printer);
        }
        Watches.Clear();
    }
}
'@

try {
  Add-Type -TypeDefinition $nativeSource -ErrorAction Stop
  Send-Message 'ready' @{ message = 'Native Windows printer change watcher initialized.' }

  while ($true) {
    if ([DateTime]::UtcNow -ge $script:nextHealthCheck) {
      $running = (Get-Service -Name Spooler -ErrorAction Stop).Status -eq 'Running'
      $printers = @()
      if ($running) {
        $printers = @(Get-Printer -ErrorAction Stop | Select-Object -ExpandProperty Name | Sort-Object -Unique)
      }
      $inventory = ($printers -join [char]31)
      $script:nextHealthCheck = [DateTime]::UtcNow.AddSeconds(30)

      if ($running -ne $script:spoolerRunning -or $inventory -ne $script:printerInventory) {
        [SecurePrintChangeWatcher]::Stop()
        $script:spoolerRunning = $running
        $script:printerInventory = $inventory
        $script:printerNames = $printers
        if ($running -and $printers.Count -gt 0) {
          [SecurePrintChangeWatcher]::Start([string[]]$printers)
          Send-Message 'state' @{ message = "Native ADD_JOB event subscriptions active for $($printers.Count) printers." }
          # Reconcile queued jobs on startup/recovery; normal new-job detection is event-driven.
          Get-CimInstance -ClassName Win32_PrintJob -ErrorAction Stop | ForEach-Object {
            Send-Message 'job' @{
              source = 'existing'
              jobName = [string]$_.Name
              jobId = [int]$_.JobId
              docName = [string]$_.Document
              owner = [string]$_.Owner
            }
          }
        } elseif (-not $running) {
          Send-Message 'state' @{ message = 'Print Spooler is stopped; printer event subscriptions are closed.' }
        } else {
          Send-Message 'state' @{ message = 'No printers are currently available for event monitoring.' }
        }
      }
    }

    if (-not $script:spoolerRunning -or $script:printerNames.Count -eq 0) {
      Start-Sleep -Seconds 5
      continue
    }

    $index = [SecurePrintChangeWatcher]::Wait(30000)
    if ($index -ge 0) {
      $printerName = [SecurePrintChangeWatcher]::Consume($index)
      $prefix = "$printerName, "
      for ($attempt = 0; $attempt -lt 3; $attempt++) {
        $jobs = @(Get-CimInstance -ClassName Win32_PrintJob -ErrorAction Stop |
          Where-Object { $_.Name.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase) })
        if ($jobs.Count -gt 0) {
          foreach ($job in $jobs) {
            Send-Message 'job' @{
              source = 'event'
              jobName = [string]$job.Name
              jobId = [int]$job.JobId
              docName = [string]$job.Document
              owner = [string]$job.Owner
            }
          }
          break
        }
        Start-Sleep -Milliseconds 100
      }
    } elseif ($index -eq -2) {
      Send-Message 'error' @{ message = 'Windows printer notification wait failed; rebuilding subscriptions.' }
      [SecurePrintChangeWatcher]::Stop()
      $script:printerInventory = ''
    }
  }
} catch {
  [SecurePrintChangeWatcher]::Stop()
  Send-Message 'error' @{ message = $_.Exception.Message }
  exit 1
}
`;
}

function launchMonitorProcess() {
  if (!isMonitoring || monitorProcess) return;

  console.log('[PrintEnforcer] Launching persistent Windows print-job event monitor...');
  let child;
  try {
    child = spawn('powershell.exe', [
      '-NoProfile',
      '-NonInteractive',
      '-ExecutionPolicy', 'Bypass',
      '-EncodedCommand', encodePowerShell(createMonitorScript())
    ], { windowsHide: true });
  } catch (error) {
    console.error('[PrintEnforcer] Monitor launch error:', error.message);
    scheduleMonitorRestart();
    return;
  }

  monitorProcess = child;
  let stdoutBuffer = '';
  child.stdout.setEncoding('utf8');
  child.stdout.on('data', (chunk) => {
    stdoutBuffer += chunk;
    const lines = stdoutBuffer.split(/\r?\n/);
    stdoutBuffer = lines.pop();
    for (const line of lines) handleMonitorMessage(line);
  });

  child.stderr.setEncoding('utf8');
  child.stderr.on('data', (chunk) => {
    const message = chunk.trim();
    if (message) console.error('[PrintEnforcer] Monitor error:', message);
  });

  child.on('error', (error) => {
    console.error('[PrintEnforcer] Monitor process error:', error.message);
  });

  child.on('close', (code, signal) => {
    if (stdoutBuffer.trim()) handleMonitorMessage(stdoutBuffer);
    if (monitorProcess !== child) return;
    monitorProcess = null;
    if (!isMonitoring) return;
    console.error(`[PrintEnforcer] Monitor exited (code=${code}, signal=${signal || 'none'}).`);
    scheduleMonitorRestart();
  });
}

function scheduleMonitorRestart() {
  if (!isMonitoring || monitorRestartTimer) return;
  const delay = monitorRestartDelay;
  monitorRestartDelay = Math.min(monitorRestartDelay * 2, 30000);
  console.error(`[PrintEnforcer] Restarting print-job monitor in ${delay}ms.`);
  monitorRestartTimer = setTimeout(() => {
    monitorRestartTimer = null;
    launchMonitorProcess();
  }, delay);
}

function handleMonitorMessage(line) {
  if (!line || !line.trim()) return;
  let message;
  try {
    message = JSON.parse(line);
  } catch (error) {
    console.error('[PrintEnforcer] Monitor returned an unreadable message:', line.trim());
    return;
  }

  if (message.type === 'ready') {
    monitorRestartDelay = 1000;
    console.log(`[PrintEnforcer] ${message.message || 'Windows print event monitor ready.'}`);
  } else if (message.type === 'state') {
    console.log(`[PrintEnforcer] ${message.message}`);
  } else if (message.type === 'error') {
    console.error('[PrintEnforcer] Monitor error:', message.message);
  } else if (message.type === 'job') {
    handleDetectedJob(message);
  }
}

function handleDetectedJob(job) {
  const jobName = String(job.jobName || '');
  const docName = String(job.docName || '');
  const key = `${jobName}|${docName}|${job.owner || ''}`;
  const now = Date.now();
  for (const [seenKey, timestamp] of recentlySeenJobs) {
    if (now - timestamp > 10000) recentlySeenJobs.delete(seenKey);
  }
  if (recentlySeenJobs.has(key)) return;
  recentlySeenJobs.set(key, now);

  const authorized = isJobWhitelisted(docName);
  const source = job.source === 'existing' ? 'existing spooler job' : 'new spooler job';
  console.log(`[PrintEnforcer] ${source} detected: "${docName || 'Unknown document'}" by ${job.owner || 'unknown owner'}; ${authorized ? 'AUTHORIZED' : 'UNAUTHORIZED'}.`);
  if (!authorized) cancelPrintJob(jobName, docName);
}

function cancelPrintJob(jobName, docName) {
  if (!jobName) {
    console.error(`[PrintEnforcer] Cannot cancel "${docName || 'Unknown document'}": detected job has no printer/job identifier.`);
    return;
  }

  const escapedJobName = jobName.replace(/'/g, "''");
  const psCancel = `
$ErrorActionPreference = 'Stop'
try {
  $job = Get-CimInstance -ClassName Win32_PrintJob -ErrorAction Stop |
    Where-Object { $_.Name -eq '${escapedJobName}' }
  if (-not $job) {
    Write-Output 'JOB_NOT_FOUND'
    exit 2
  }
  Remove-CimInstance -InputObject $job -ErrorAction Stop
  Write-Output 'JOB_CANCELLED'
} catch {
  [Console]::Error.WriteLine($_.Exception.Message)
  exit 1
}
`;

  console.log(`[PrintEnforcer] Cancelling unauthorized job "${docName || 'Unknown document'}" (${jobName}).`);
  const child = spawn('powershell.exe', [
    '-NoProfile',
    '-NonInteractive',
    '-ExecutionPolicy', 'Bypass',
    '-EncodedCommand', encodePowerShell(psCancel)
  ], { windowsHide: true });
  let stdout = '';
  let stderr = '';
  child.stdout.setEncoding('utf8');
  child.stderr.setEncoding('utf8');
  child.stdout.on('data', chunk => { stdout += chunk; });
  child.stderr.on('data', chunk => { stderr += chunk; });
  child.on('error', error => {
    console.error('[PrintEnforcer] Cancellation process error:', error.message);
  });
  child.on('close', code => {
    if (code === 0 && stdout.includes('JOB_CANCELLED')) {
      console.log(`[PrintEnforcer] Unauthorized job cancelled: "${docName || 'Unknown document'}" (${jobName}).`);
    } else if (stdout.includes('JOB_NOT_FOUND')) {
      console.error(`[PrintEnforcer] Could not cancel unauthorized job "${docName || 'Unknown document'}": it was no longer in the spooler.`);
    } else {
      console.error(`[PrintEnforcer] Failed to cancel unauthorized job "${docName || 'Unknown document'}": ${stderr.trim() || `PowerShell exited with code ${code}.`}`);
    }
  });

  // Show notification to the user
  showBlockedNotification(docName);
}

function showBlockedNotification(docName) {
  try {
    const notification = new Notification({
      title: 'SecurePrint — Print Blocked',
      body: `"${docName || 'Unknown document'}" was blocked.\nAll printing must go through SecurePrint.`,
      icon: path.join(__dirname, '..', 'assets', 'icon.png'),
      urgency: 'critical'
    });
    notification.show();
  } catch (e) {
    console.log('[PrintEnforcer] Could not show notification:', e.message);
  }
}

// ─── Network Printer Port Blocking ───

function blockDirectPrinterPorts() {
  if (process.platform !== 'win32') return Promise.resolve();

  console.log('[PrintEnforcer] Blocking direct printer network ports...');

  const psScript = `
    try {
      # Block RAW printing (port 9100)
      New-NetFirewallRule -DisplayName 'SecurePrint-Block-RAW-9100' -Direction Outbound -LocalPort 9100 -Protocol TCP -Action Block -ErrorAction SilentlyContinue
      # Block LPR printing (port 515)
      New-NetFirewallRule -DisplayName 'SecurePrint-Block-LPR-515' -Direction Outbound -LocalPort 515 -Protocol TCP -Action Block -ErrorAction SilentlyContinue
      # Block IPP printing (port 631)
      New-NetFirewallRule -DisplayName 'SecurePrint-Block-IPP-631' -Direction Outbound -LocalPort 631 -Protocol TCP -Action Block -ErrorAction SilentlyContinue
      Write-Output 'PORTS_BLOCKED'
    } catch {
      Write-Output "PORT_ERROR: $_"
    }
  `;

  return runElevatedPowerShell(psScript);
}

function unblockDirectPrinterPorts() {
  if (process.platform !== 'win32') return Promise.resolve();

  const psScript = `
    try {
      Remove-NetFirewallRule -DisplayName 'SecurePrint-Block-RAW-9100' -ErrorAction SilentlyContinue
      Remove-NetFirewallRule -DisplayName 'SecurePrint-Block-LPR-515' -ErrorAction SilentlyContinue
      Remove-NetFirewallRule -DisplayName 'SecurePrint-Block-IPP-631' -ErrorAction SilentlyContinue
      Write-Output 'PORTS_UNBLOCKED'
    } catch {
      Write-Output "PORT_ERROR: $_"
    }
  `;

  return runElevatedPowerShell(psScript);
}

// ─── Printer Visibility Control ───

function hideAllPrintersExcept(allowedPrinterNames) {
  if (process.platform !== 'win32') return Promise.resolve();

  const allowed = (allowedPrinterNames || []).map(n => `'${n.replace(/'/g, "''")}'`).join(',');

  const psScript = `
    try {
      $allowed = @(${allowed})
      $printers = Get-Printer -ErrorAction SilentlyContinue
      foreach ($p in $printers) {
        if ($allowed -notcontains $p.Name) {
          # Set printer to offline / hidden
          Set-Printer -Name $p.Name -PermissionSDDL $null -ErrorAction SilentlyContinue
          Write-Output "HIDDEN: $($p.Name)"
        }
      }
    } catch {
      Write-Output "HIDE_ERROR: $_"
    }
  `;

  return runElevatedPowerShell(psScript);
}

// ─── Enforce All Policies ───

async function enforceAllPolicies() {
  console.log('[PrintEnforcer] Enforcing all print security policies...');
  const results = [];

  try {
    await blockDirectPrinterPorts();
    results.push('Direct printer ports blocked');
  } catch (e) {
    results.push('Port block failed (needs admin): ' + e.message);
  }

  startMonitoring();
  results.push('Spooler monitor active');

  console.log('[PrintEnforcer] Policy enforcement results:', results.join('; '));
  return results;
}

async function removeAllPolicies() {
  console.log('[PrintEnforcer] Removing all print security policies...');
  stopMonitoring();

  try { await unblockDirectPrinterPorts(); } catch (e) { /* ignore */ }
}

// ─── Get Enforcer Status ───

function getStatus() {
  return {
    spoolerMonitorActive: isMonitoring,
    whitelistedJobs: Array.from(whitelistedJobs),
    platform: process.platform
  };
}

// ─── Utility ───

function runElevatedPowerShell(script) {
  return new Promise((resolve, reject) => {
    const escaped = script.replace(/"/g, '\\"');
    exec(
      `powershell -NoProfile -ExecutionPolicy Bypass -Command "${escaped}"`,
      { timeout: 30000 },
      (err, stdout, stderr) => {
        if (err) {
          // Try with elevation
          console.log('[PrintEnforcer] Standard exec failed, may need admin rights.');
          reject(new Error(stderr || err.message));
        } else {
          console.log('[PrintEnforcer] PS output:', stdout.trim());
          resolve(stdout.trim());
        }
      }
    );
  });
}

module.exports = {
  // Whitelist
  whitelistJob,
  removeWhitelistedJob,
  isJobWhitelisted,
  // Monitor
  startMonitoring,
  stopMonitoring,
  // Ports
  blockDirectPrinterPorts,
  unblockDirectPrinterPorts,
  // Printer visibility
  hideAllPrintersExcept,
  // Combined
  enforceAllPolicies,
  removeAllPolicies,
  // Status
  getStatus
};
